package com.TravelManagement.Dto

class ReservationUpdateRequest {
    var id: Long? = null
    var checkedIn: Boolean? = null
    var numberOfBags: Int? = null
}