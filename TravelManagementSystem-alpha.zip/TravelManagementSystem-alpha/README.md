# Travel Management System

1) Install Intellij IDE

2) Install Java 1.8

3) Clone the repository

4) Build the application, change to Java 1.8 SK, and select change language level to 8-Annotations etc.

5) Run the Application 

6) Go to Chrome/ any browser and click: http://localhost:8080/abc-airlines/
